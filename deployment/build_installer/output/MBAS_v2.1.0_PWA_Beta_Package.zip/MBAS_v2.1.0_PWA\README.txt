MBAS v2.1.0 PWA - Portable Edition
=====================================

This is a portable version of MBAS that doesn't require installation.

Quick Start:
1. Run INSTALL_PWA.bat to install Python dependencies
2. Run START_MBAS_PWA.bat to start the server
3. Open browser to http://localhost:8000
4. Login with admin/admin123

For mobile testing, see MOBILE_TESTING_GUIDE.txt
For more details, see PWA_QUICK_START.txt

Beta License: STANDARD tier, perpetual
Replace mbas.license with production license after testing.
