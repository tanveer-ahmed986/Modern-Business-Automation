"""
MBAS System Tray Application
Runs MBAS server in background without CMD window.
Provides system tray icon for start/stop/exit.
"""

import sys
import subprocess
import psutil
import os
import webbrowser
from pathlib import Path
from threading import Thread
import time

try:
    import pystray
    from PIL import Image, ImageDraw
except ImportError:
    print("Installing required packages...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pystray", "Pillow", "psutil"])
    import pystray
    from PIL import Image, ImageDraw


class MBASTrayApp:
    def __init__(self):
        self.server_process = None
        self.icon = None
        self.is_running = False

        # Get paths
        self.script_dir = Path(__file__).resolve().parent
        self.project_dir = self.script_dir.parent
        self.backend_dir = self.project_dir / "backend"
        self.venv_python = self.project_dir / "venv" / "Scripts" / "pythonw.exe"

        # Fallback to regular python if pythonw not found
        if not self.venv_python.exists():
            self.venv_python = self.project_dir / "venv" / "Scripts" / "python.exe"

        self.server_script = self.backend_dir / "src" / "main.py"
        self.server_url = "http://127.0.0.1:8000"

    def create_icon_image(self, color="green"):
        """Create system tray icon image"""
        # Create a simple colored circle icon
        width = 64
        height = 64
        image = Image.new('RGB', (width, height), color='white')
        dc = ImageDraw.Draw(image)

        # Draw circle
        if color == "green":
            fill_color = (34, 197, 94)  # Green when running
        elif color == "red":
            fill_color = (239, 68, 68)  # Red when stopped
        else:
            fill_color = (156, 163, 175)  # Gray when starting

        dc.ellipse([8, 8, 56, 56], fill=fill_color, outline='black', width=2)

        # Draw M in center
        dc.text((20, 15), "M", fill='white', font=None)

        return image

    def is_server_running(self):
        """Check if server is already running on port 8000"""
        for conn in psutil.net_connections():
            if conn.laddr.port == 8000 and conn.status == 'LISTEN':
                return True
        return False

    def find_server_process(self):
        """Find the uvicorn server process"""
        for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                cmdline = proc.info.get('cmdline')
                if cmdline and 'uvicorn' in ' '.join(cmdline) and 'src.main:app' in ' '.join(cmdline):
                    return proc
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return None

    def start_server(self, icon=None, item=None):
        """Start MBAS server in background"""
        if self.is_running or self.is_server_running():
            if icon:
                icon.notify("MBAS is already running!", "MBAS Server")
            return

        try:
            # Update icon to starting state
            if icon:
                icon.icon = self.create_icon_image("gray")
                icon.notify("Starting MBAS server...", "MBAS Server")

            # Change to backend directory
            os.chdir(str(self.backend_dir))

            # Start server process hidden (no window)
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = subprocess.SW_HIDE

            self.server_process = subprocess.Popen(
                [
                    str(self.venv_python),
                    "-m", "uvicorn",
                    "src.main:app",
                    "--host", "127.0.0.1",
                    "--port", "8000"
                ],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                startupinfo=startupinfo,
                cwd=str(self.backend_dir)
            )

            # Wait for server to start
            time.sleep(3)

            if self.is_server_running():
                self.is_running = True
                if icon:
                    icon.icon = self.create_icon_image("green")
                    icon.notify("MBAS server started successfully!", "MBAS Server")
                    icon.title = "MBAS - Running"
            else:
                raise Exception("Server failed to start")

        except Exception as e:
            self.is_running = False
            if icon:
                icon.icon = self.create_icon_image("red")
                icon.notify(f"Failed to start server: {str(e)}", "MBAS Server")
                icon.title = "MBAS - Stopped"

    def stop_server(self, icon=None, item=None):
        """Stop MBAS server"""
        if not self.is_running and not self.is_server_running():
            if icon:
                icon.notify("MBAS is not running!", "MBAS Server")
            return

        try:
            if icon:
                icon.notify("Stopping MBAS server...", "MBAS Server")

            # Find and kill the server process
            proc = self.find_server_process()
            if proc:
                proc.terminate()
                proc.wait(timeout=5)

            # Also try to kill by port
            for conn in psutil.net_connections():
                if conn.laddr.port == 8000 and conn.status == 'LISTEN':
                    try:
                        proc = psutil.Process(conn.pid)
                        proc.terminate()
                    except:
                        pass

            if self.server_process:
                try:
                    self.server_process.terminate()
                    self.server_process.wait(timeout=5)
                except:
                    pass

            self.is_running = False
            self.server_process = None

            if icon:
                icon.icon = self.create_icon_image("red")
                icon.notify("MBAS server stopped", "MBAS Server")
                icon.title = "MBAS - Stopped"

        except Exception as e:
            if icon:
                icon.notify(f"Error stopping server: {str(e)}", "MBAS Server")

    def open_browser(self, icon=None, item=None):
        """Open MBAS in browser"""
        if not self.is_running and not self.is_server_running():
            if icon:
                icon.notify("Server is not running. Starting now...", "MBAS Server")
            self.start_server(icon)
            time.sleep(3)  # Wait for server to start

        webbrowser.open(self.server_url)

    def show_status(self, icon=None, item=None):
        """Show server status"""
        status = "Running" if (self.is_running or self.is_server_running()) else "Stopped"
        if icon:
            icon.notify(f"Server Status: {status}\nURL: {self.server_url}", "MBAS Server")

    def exit_app(self, icon=None, item=None):
        """Exit application and stop server"""
        self.stop_server(icon)
        if icon:
            icon.stop()

    def run(self):
        """Run the system tray application"""
        # Create menu
        menu = pystray.Menu(
            pystray.MenuItem("Open MBAS", self.open_browser, default=True),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Start Server", self.start_server),
            pystray.MenuItem("Stop Server", self.stop_server),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Status", self.show_status),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Exit", self.exit_app)
        )

        # Check if server is already running
        if self.is_server_running():
            self.is_running = True
            icon_image = self.create_icon_image("green")
            title = "MBAS - Running"
        else:
            icon_image = self.create_icon_image("red")
            title = "MBAS - Stopped"

        # Create system tray icon
        self.icon = pystray.Icon(
            "mbas",
            icon_image,
            title,
            menu
        )

        # Auto-start server on launch
        Thread(target=self.start_server, args=(self.icon,)).start()

        # Auto-open browser after server starts (professional experience)
        Thread(target=self.auto_open_browser).start()

        # Run the icon
        self.icon.run()

    def auto_open_browser(self):
        """Automatically open browser after server starts"""
        # Wait for server to be ready
        max_wait = 10  # seconds
        for _ in range(max_wait):
            time.sleep(1)
            if self.is_server_running():
                time.sleep(2)  # Extra delay to ensure server is fully ready
                webbrowser.open(self.server_url)
                break


if __name__ == "__main__":
    app = MBASTrayApp()
    app.run()
