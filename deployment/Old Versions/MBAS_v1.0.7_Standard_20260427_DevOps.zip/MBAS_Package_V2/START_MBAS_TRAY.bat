@echo off
title MBAS System Tray Launcher
color 0A

REM Check if virtual environment exists
if not exist "%~dp0..\venv\Scripts\python.exe" (
    echo [ERROR] Virtual environment not found!
    echo Please run INSTALL.bat first.
    echo.
    pause
    exit /b 1
)

REM Activate virtual environment
call "%~dp0..\venv\Scripts\activate.bat"

REM Install required packages for tray app
echo [*] Installing system tray dependencies...
python -m pip install pystray Pillow psutil --quiet

REM Start MBAS in system tray (hidden)
echo [*] Starting MBAS System Tray Application...
start /B pythonw "%~dp0mbas_tray.py"

REM Wait a moment then close this window
timeout /t 2 /nobreak >nul

echo [OK] MBAS is now running in system tray!
echo.
echo Look for the MBAS icon in your system tray (bottom-right corner).
echo Right-click the icon to:
echo   - Open MBAS (in browser)
echo   - Start/Stop Server
echo   - Exit
echo.
timeout /t 3 /nobreak >nul
exit
